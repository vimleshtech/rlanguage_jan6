
n1 = 11
n2 =33

n=n1+n2

print(n)


is.numeric(n1)
is.character(n1)
is.character(n2)

a ="skhhsjgssfhsg"
is.character(a)


a ="1"
b ="2"
is.numeric(a)
is.numeric(b)

a = as.numeric(a) 
b = as.numeric(a)
is.numeric(a)
is.numeric(b)



c =a+b
print(c)


letters

LETTERS


month.name

##########################
#vector 
age = c(22,33,56,71,23,41,12)

#print/ show all data or values
print(age)

#access element by index
print(age[2])

##generate the sequence
s = c(1:10) #from 1 to 10

#factor 
gender = c("male","female","male","male","male","female")
gender = as.factor(gender)


#matrix
a = c(1:9)

matrix(a,nrow = 3, ncol = 3)
matrix(a,nrow = 3, ncol = 3,byrow = TRUE)

matrix(a,nrow = 3, ncol = 2)


#cbind 
id  =c(1,2,3,5,6,100)
name  =c("raman","jatin","divya","ayush","monika","ridhi")

cbind(id,name)

#rbind 
rbind(id,name)


##dataframe 
emp = data.frame(id,name)

emp$name

##Arithmetic Operation 
90+2
90-2

print(90+2)

###
a = 12
b = 2

c =a+b
print(c)

#
print(a-b)

#
a*b
a**b  #power 
a^b  #power 

a/10  #with decimal 

a%%10   #moduls, after decimal 

a%/%10  #non-decimal , before decimal 


a*.05   #5%  #  a*5/100 

a*1.05   #105%    a+ (a*5/100)  

#or 
a + a*.05 


##condition  : if statement
a =110
b =33
#show greater no
if(a>b){
    
  print("a is greater")
  
}else{
  
  print("b is greater")
  
}

#check given no is even or odd
a =15
if( a%%2 == 0)
{
  print("even no")
}else{
  
  print("odd no")
}

#if else condition 
a =1
b =330
c =44 

if(a>b && a>c){
  
  print("a is greater")
  
}else if(b>a && b>c){
  
  print("b is greater")
}else{
  print("c is greater")
  
}


##tax 
amt = 12000
tax = 0

if(amt>5000){
  
  tax = amt*.18
  
}else if(amt>1000){
  
  tax = amt*.10
  
}else if(amt>500){
  
  tax = amt*.05
  
}

total = amt+tax
print(total)


#while loop 
i =1  #init  / start from 
while(i<=1000){  #condition 
  
  print(i)
  i =i+1  #incement
}

#print in reverse order 
i =10  #init  / start from 
while(i>0){  #condition 
  
  print(i)
  i =i-1  #decement
}

#print all odd numebrs between 2 to 30
i =2
while(i<=30){
  
  print(i)
  i = i+2
}


#break 
i =1
while(i<=30){
    
  if(i%%4 ==0){  # 1%%4 is 0 
    break
  }
  print(i)
  i=i+1
  
}
#repeat
i=1
repeat{
  
  print(i)
  i =i+1
  
  if(i==10){
    break
  }
  
}
  

##for loop 
v = c(11,22,33,21,1,12222,333,444,555)

for(x in v){
  print(x)
}

#get sum of all values
s =0

for(x in v){
 s =s+x
}
print(s)

#get count of odd numbers
oc =0

for(x in v){

    if(x%%2 >0){
      
    oc=oc+1
  }
}
print(oc)














